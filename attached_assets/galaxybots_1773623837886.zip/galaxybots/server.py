"""
GalaxyBots MCP Server
FastAPI-based SSE server exposing Claude tools for autonomous business operation.
Run with: uvicorn server:app --host 0.0.0.0 --port 8000 --reload
"""

import json
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from tools.universal import UniversalTools
from tools.data import DataTools
from tools.actions import ActionTools
from adapters.loader import AdapterLoader

# ── Tool registry ────────────────────────────────────────────────────────────

def build_tool_registry(company_id: str) -> dict:
    """Return all tool handlers keyed by tool name for a given company."""
    adapter = AdapterLoader.load(company_id)
    universal = UniversalTools()
    data      = DataTools(adapter)
    actions   = ActionTools(adapter)

    return {
        # Universal
        "web_search":        universal.web_search,
        "send_email":        universal.send_email,
        "read_file":         universal.read_file,
        "write_file":        universal.write_file,
        "http_request":      universal.http_request,
        "schedule_task":     universal.schedule_task,
        # Data (business-aware)
        "get_company_info":  data.get_company_info,
        "list_customers":    data.list_customers,
        "get_customer":      data.get_customer,
        "get_open_tasks":    data.get_open_tasks,
        "get_metrics":       data.get_metrics,
        "search_records":    data.search_records,
        # Actions (write operations)
        "create_record":     actions.create_record,
        "update_record":     actions.update_record,
        "create_invoice":    actions.create_invoice,
        "trigger_workflow":  actions.trigger_workflow,
        "notify_team":       actions.notify_team,
        "log_decision":      actions.log_decision,
        "post_to_platform":  actions.post_to_platform,
    }


# ── MCP tool definitions (sent to Claude) ────────────────────────────────────

TOOL_DEFINITIONS = [
    {
        "name": "web_search",
        "description": "Search the web for current information.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "num_results": {"type": "integer", "default": 5}
            },
            "required": ["query"]
        }
    },
    {
        "name": "send_email",
        "description": "Send an email on behalf of the business.",
        "input_schema": {
            "type": "object",
            "properties": {
                "to":      {"type": "string"},
                "subject": {"type": "string"},
                "body":    {"type": "string"},
                "cc":      {"type": "string", "description": "Optional CC address"}
            },
            "required": ["to", "subject", "body"]
        }
    },
    {
        "name": "http_request",
        "description": "Make an HTTP request to an external API.",
        "input_schema": {
            "type": "object",
            "properties": {
                "url":     {"type": "string"},
                "method":  {"type": "string", "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"], "default": "GET"},
                "headers": {"type": "object"},
                "body":    {"type": "object"}
            },
            "required": ["url"]
        }
    },
    {
        "name": "schedule_task",
        "description": "Schedule a future task or reminder.",
        "input_schema": {
            "type": "object",
            "properties": {
                "task":        {"type": "string", "description": "Description of what to do"},
                "run_at":      {"type": "string", "description": "ISO datetime or natural language like 'tomorrow 9am'"},
                "assignee":    {"type": "string", "description": "Who should handle it (bot or person name)"}
            },
            "required": ["task", "run_at"]
        }
    },
    {
        "name": "get_company_info",
        "description": "Get profile, SOPs, integrations, and context for the current business.",
        "input_schema": {"type": "object", "properties": {}}
    },
    {
        "name": "list_customers",
        "description": "List customers/clients for the current business.",
        "input_schema": {
            "type": "object",
            "properties": {
                "filter":  {"type": "string", "description": "Optional filter e.g. 'active', 'overdue'"},
                "limit":   {"type": "integer", "default": 20}
            }
        }
    },
    {
        "name": "get_customer",
        "description": "Get full details for a specific customer.",
        "input_schema": {
            "type": "object",
            "properties": {
                "customer_id": {"type": "string"}
            },
            "required": ["customer_id"]
        }
    },
    {
        "name": "get_open_tasks",
        "description": "Get all open/pending tasks for the business.",
        "input_schema": {
            "type": "object",
            "properties": {
                "priority": {"type": "string", "enum": ["all", "high", "medium", "low"], "default": "all"},
                "assigned_to": {"type": "string", "description": "Filter by assignee"}
            }
        }
    },
    {
        "name": "get_metrics",
        "description": "Get business KPIs and metrics.",
        "input_schema": {
            "type": "object",
            "properties": {
                "metric":    {"type": "string", "description": "e.g. 'revenue', 'leads', 'support_tickets'"},
                "period":    {"type": "string", "description": "e.g. 'today', 'this_week', 'last_30_days'", "default": "this_week"}
            },
            "required": ["metric"]
        }
    },
    {
        "name": "search_records",
        "description": "Full-text search across all business records.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query":       {"type": "string"},
                "record_type": {"type": "string", "description": "e.g. 'customers', 'orders', 'leads', 'all'", "default": "all"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "create_record",
        "description": "Create a new record (customer, lead, order, task, etc.).",
        "input_schema": {
            "type": "object",
            "properties": {
                "record_type": {"type": "string"},
                "data":        {"type": "object", "description": "Fields for the new record"}
            },
            "required": ["record_type", "data"]
        }
    },
    {
        "name": "update_record",
        "description": "Update an existing record.",
        "input_schema": {
            "type": "object",
            "properties": {
                "record_type": {"type": "string"},
                "record_id":   {"type": "string"},
                "data":        {"type": "object", "description": "Fields to update"}
            },
            "required": ["record_type", "record_id", "data"]
        }
    },
    {
        "name": "create_invoice",
        "description": "Create and optionally send an invoice to a customer.",
        "input_schema": {
            "type": "object",
            "properties": {
                "customer_id":   {"type": "string"},
                "line_items":    {"type": "array", "items": {"type": "object"}},
                "due_date":      {"type": "string"},
                "send_to_email": {"type": "boolean", "default": False}
            },
            "required": ["customer_id", "line_items"]
        }
    },
    {
        "name": "trigger_workflow",
        "description": "Trigger an automation workflow (e.g. onboarding, follow-up sequence).",
        "input_schema": {
            "type": "object",
            "properties": {
                "workflow_name": {"type": "string"},
                "context":       {"type": "object", "description": "Variables to pass into the workflow"}
            },
            "required": ["workflow_name"]
        }
    },
    {
        "name": "notify_team",
        "description": "Send a notification to a team member or channel.",
        "input_schema": {
            "type": "object",
            "properties": {
                "channel":   {"type": "string", "description": "e.g. 'slack', 'email', 'sms'"},
                "recipient": {"type": "string"},
                "message":   {"type": "string"},
                "urgency":   {"type": "string", "enum": ["normal", "high"], "default": "normal"}
            },
            "required": ["channel", "recipient", "message"]
        }
    },
    {
        "name": "log_decision",
        "description": "Log an autonomous decision made by the bot for audit trail.",
        "input_schema": {
            "type": "object",
            "properties": {
                "decision":    {"type": "string"},
                "reasoning":   {"type": "string"},
                "confidence":  {"type": "number", "description": "0.0 to 1.0"},
                "requires_review": {"type": "boolean", "default": False}
            },
            "required": ["decision", "reasoning"]
        }
    },
    {
        "name": "post_to_platform",
        "description": "Post content to a platform (social media, CMS, job board, etc.).",
        "input_schema": {
            "type": "object",
            "properties": {
                "platform": {"type": "string", "description": "e.g. 'twitter', 'linkedin', 'wordpress'"},
                "content":  {"type": "string"},
                "media_url": {"type": "string", "description": "Optional image/video URL"}
            },
            "required": ["platform", "content"]
        }
    },
    {
        "name": "read_file",
        "description": "Read a file from the business file store.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"}
            },
            "required": ["path"]
        }
    },
    {
        "name": "write_file",
        "description": "Write or append to a file in the business file store.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path":    {"type": "string"},
                "content": {"type": "string"},
                "mode":    {"type": "string", "enum": ["write", "append"], "default": "write"}
            },
            "required": ["path", "content"]
        }
    },
]


# ── SSE helpers ───────────────────────────────────────────────────────────────

def sse_event(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


async def mcp_sse_stream(request: Request, company_id: str):
    """Core SSE generator that speaks the MCP protocol."""
    registry = build_tool_registry(company_id)

    # 1. Send server capabilities
    yield sse_event("endpoint", {
        "type": "endpoint",
        "tools": TOOL_DEFINITIONS
    })

    # 2. Listen for incoming tool call requests via query param / body
    # In production this would be a persistent connection; here we yield keep-alives
    try:
        while True:
            if await request.is_disconnected():
                break
            yield ": keep-alive\n\n"
            await asyncio.sleep(15)
    except asyncio.CancelledError:
        pass


# ── FastAPI app ───────────────────────────────────────────────────────────────

app = FastAPI(title="GalaxyBots MCP Server", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {"status": "GalaxyBots MCP Server running", "version": "1.0.0"}


@app.get("/health")
async def health():
    return {"healthy": True}


@app.get("/sse/{company_id}")
async def sse_endpoint(company_id: str, request: Request):
    """SSE endpoint — pass this URL to Claude API as your MCP server."""
    return StreamingResponse(
        mcp_sse_stream(request, company_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        }
    )


@app.post("/tool/{company_id}/{tool_name}")
async def call_tool(company_id: str, tool_name: str, request: Request):
    """
    Direct tool invocation endpoint.
    Claude's API calls this when it wants to use a tool.
    """
    try:
        body = await request.json()
    except Exception:
        body = {}

    registry = build_tool_registry(company_id)

    if tool_name not in registry:
        return JSONResponse(
            status_code=404,
            content={"error": f"Tool '{tool_name}' not found"}
        )

    try:
        result = await registry[tool_name](**body)
        return {"result": result, "tool": tool_name, "company_id": company_id}
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "tool": tool_name}
        )


@app.get("/tools")
async def list_tools():
    """List all available tool definitions."""
    return {"tools": TOOL_DEFINITIONS, "count": len(TOOL_DEFINITIONS)}


@app.get("/adapters")
async def list_adapters():
    """List all plugged-in businesses."""
    return {"companies": AdapterLoader.list_companies()}
