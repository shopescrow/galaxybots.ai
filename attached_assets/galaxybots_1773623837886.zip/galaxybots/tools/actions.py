"""
Action tools — write operations. These modify state in the real world.
Each action logs itself for audit trail before executing.
"""

import os
import json
import uuid
import aiofiles
import aiohttp
from datetime import datetime
from typing import Optional


class ActionTools:
    def __init__(self, adapter: dict):
        self.adapter = adapter
        self.company_id = adapter.get("company_id", "unknown")

    def _can_do(self, permission: str) -> bool:
        """Check if the bot is permitted to take this action autonomously."""
        perms = self.adapter.get("bot_permissions", {})
        return perms.get(permission, False)

    async def _audit_log(self, action: str, data: dict):
        """Append every action to the company audit log."""
        entry = {
            "id":         str(uuid.uuid4())[:8],
            "timestamp":  datetime.utcnow().isoformat(),
            "company_id": self.company_id,
            "action":     action,
            "data":       data
        }
        os.makedirs(f"data/{self.company_id}", exist_ok=True)
        async with aiofiles.open(f"data/{self.company_id}/audit_log.jsonl", "a") as f:
            await f.write(json.dumps(entry) + "\n")

    async def create_record(self, record_type: str, data: dict) -> dict:
        """Create a new record in the local JSON store."""
        await self._audit_log("create_record", {"record_type": record_type, "data": data})

        store_path = f"data/{self.company_id}/{record_type}.json"
        os.makedirs(f"data/{self.company_id}", exist_ok=True)

        records = []
        if os.path.exists(store_path):
            with open(store_path) as f:
                records = json.load(f)

        new_record = {
            "id":         str(uuid.uuid4())[:8],
            "created_at": datetime.utcnow().isoformat(),
            **data
        }
        records.append(new_record)

        with open(store_path, "w") as f:
            json.dump(records, f, indent=2)

        return {"created": True, "record": new_record, "record_type": record_type}

    async def update_record(self, record_type: str, record_id: str, data: dict) -> dict:
        """Update fields on an existing record."""
        await self._audit_log("update_record", {"record_type": record_type, "record_id": record_id, "data": data})

        store_path = f"data/{self.company_id}/{record_type}.json"
        if not os.path.exists(store_path):
            return {"updated": False, "error": f"No store found for {record_type}"}

        with open(store_path) as f:
            records = json.load(f)

        updated = False
        for record in records:
            if str(record.get("id")) == str(record_id):
                record.update(data)
                record["updated_at"] = datetime.utcnow().isoformat()
                updated = True
                break

        if updated:
            with open(store_path, "w") as f:
                json.dump(records, f, indent=2)

        return {"updated": updated, "record_id": record_id, "record_type": record_type}

    async def create_invoice(
        self,
        customer_id: str,
        line_items: list,
        due_date: Optional[str] = None,
        send_to_email: bool = False
    ) -> dict:
        """
        Create an invoice. If Stripe is configured, creates a real Stripe invoice.
        Otherwise saves locally.
        """
        await self._audit_log("create_invoice", {"customer_id": customer_id, "line_items": line_items})

        stripe_key = self.adapter.get("integrations", {}).get("stripe_secret_key") or os.getenv("STRIPE_SECRET_KEY")

        if stripe_key:
            headers = {"Authorization": f"Bearer {stripe_key}"}
            # Create invoice items then invoice via Stripe API
            async with aiohttp.ClientSession() as session:
                for item in line_items:
                    await session.post(
                        "https://api.stripe.com/v1/invoiceitems",
                        data={
                            "customer": customer_id,
                            "amount": int(item.get("amount", 0) * 100),
                            "currency": "usd",
                            "description": item.get("description", "")
                        },
                        headers=headers
                    )

                invoice_data = {"customer": customer_id, "auto_advance": "false"}
                if due_date:
                    invoice_data["due_date"] = due_date
                if send_to_email:
                    invoice_data["collection_method"] = "send_invoice"

                async with session.post(
                    "https://api.stripe.com/v1/invoices",
                    data=invoice_data,
                    headers=headers
                ) as resp:
                    invoice = await resp.json()
                    return {"created": True, "invoice_id": invoice.get("id"), "source": "stripe", "status": invoice.get("status")}

        # Local fallback
        total = sum(item.get("amount", 0) for item in line_items)
        invoice = {
            "id":          f"INV-{str(uuid.uuid4())[:6].upper()}",
            "customer_id": customer_id,
            "line_items":  line_items,
            "total":       total,
            "due_date":    due_date,
            "status":      "draft",
            "created_at":  datetime.utcnow().isoformat()
        }

        store_path = f"data/{self.company_id}/invoices.json"
        invoices = []
        if os.path.exists(store_path):
            with open(store_path) as f:
                invoices = json.load(f)
        invoices.append(invoice)
        with open(store_path, "w") as f:
            json.dump(invoices, f, indent=2)

        return {"created": True, "invoice": invoice, "source": "local"}

    async def trigger_workflow(self, workflow_name: str, context: Optional[dict] = None) -> dict:
        """
        Trigger a named workflow. Checks adapter for workflow definitions,
        otherwise calls a webhook if configured.
        """
        await self._audit_log("trigger_workflow", {"workflow_name": workflow_name, "context": context})

        workflows = self.adapter.get("workflows", {})
        workflow = workflows.get(workflow_name)

        if not workflow:
            return {"triggered": False, "error": f"Workflow '{workflow_name}' not defined in adapter"}

        # Webhook-based workflow
        if workflow.get("type") == "webhook":
            payload = {"workflow": workflow_name, "context": context or {}, "company_id": self.company_id}
            async with aiohttp.ClientSession() as session:
                async with session.post(workflow["url"], json=payload) as resp:
                    return {"triggered": True, "workflow": workflow_name, "status": resp.status, "type": "webhook"}

        # Log-only workflow (for chained bot tasks)
        if workflow.get("type") == "bot_task":
            task_entry = {
                "workflow":   workflow_name,
                "steps":      workflow.get("steps", []),
                "context":    context or {},
                "status":     "queued",
                "queued_at":  datetime.utcnow().isoformat()
            }
            os.makedirs(f"data/{self.company_id}", exist_ok=True)
            async with aiofiles.open(f"data/{self.company_id}/workflow_queue.jsonl", "a") as f:
                await f.write(json.dumps(task_entry) + "\n")
            return {"triggered": True, "workflow": workflow_name, "type": "bot_task", "queued": True}

        return {"triggered": False, "error": "Unknown workflow type"}

    async def notify_team(self, channel: str, recipient: str, message: str, urgency: str = "normal") -> dict:
        """Send a notification via Slack, email, or SMS."""
        await self._audit_log("notify_team", {"channel": channel, "recipient": recipient, "urgency": urgency})

        integrations = self.adapter.get("integrations", {})

        if channel == "slack":
            webhook_url = integrations.get("slack_webhook") or os.getenv("SLACK_WEBHOOK_URL")
            if webhook_url:
                emoji = ":rotating_light:" if urgency == "high" else ":robot_face:"
                payload = {"text": f"{emoji} *[GalaxyBot → {recipient}]*\n{message}"}
                async with aiohttp.ClientSession() as session:
                    async with session.post(webhook_url, json=payload) as resp:
                        return {"sent": resp.status == 200, "channel": "slack", "recipient": recipient}
            return {"sent": False, "note": "No SLACK_WEBHOOK_URL configured"}

        if channel == "email":
            # Delegate to universal send_email
            from tools.universal import UniversalTools
            return await UniversalTools().send_email(
                to=recipient,
                subject=f"{'[URGENT] ' if urgency == 'high' else ''}GalaxyBot notification",
                body=message
            )

        # SMS via Twilio
        if channel == "sms":
            twilio_sid    = os.getenv("TWILIO_ACCOUNT_SID")
            twilio_token  = os.getenv("TWILIO_AUTH_TOKEN")
            twilio_from   = os.getenv("TWILIO_FROM_NUMBER")
            if twilio_sid and twilio_token:
                url = f"https://api.twilio.com/2010-04-01/Accounts/{twilio_sid}/Messages.json"
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        url,
                        data={"From": twilio_from, "To": recipient, "Body": message},
                        auth=aiohttp.BasicAuth(twilio_sid, twilio_token)
                    ) as resp:
                        data = await resp.json()
                        return {"sent": resp.status == 201, "sid": data.get("sid"), "channel": "sms"}
            return {"sent": False, "note": "Twilio env vars not set"}

        return {"sent": False, "error": f"Unknown channel: {channel}"}

    async def log_decision(
        self,
        decision: str,
        reasoning: str,
        confidence: float = 1.0,
        requires_review: bool = False
    ) -> dict:
        """Log an autonomous decision for audit and human review."""
        entry = {
            "id":              str(uuid.uuid4())[:8],
            "timestamp":       datetime.utcnow().isoformat(),
            "company_id":      self.company_id,
            "decision":        decision,
            "reasoning":       reasoning,
            "confidence":      confidence,
            "requires_review": requires_review,
            "reviewed":        False
        }

        os.makedirs(f"data/{self.company_id}", exist_ok=True)
        async with aiofiles.open(f"data/{self.company_id}/decision_log.jsonl", "a") as f:
            await f.write(json.dumps(entry) + "\n")

        if requires_review:
            print(f"[REVIEW NEEDED] {decision} (confidence: {confidence})")

        return {"logged": True, "id": entry["id"], "requires_review": requires_review}

    async def post_to_platform(self, platform: str, content: str, media_url: Optional[str] = None) -> dict:
        """Post content to a social or content platform."""
        await self._audit_log("post_to_platform", {"platform": platform, "content_preview": content[:100]})

        integrations = self.adapter.get("integrations", {})

        if platform == "twitter":
            bearer = integrations.get("twitter_bearer") or os.getenv("TWITTER_BEARER_TOKEN")
            if not bearer:
                return {"posted": False, "note": "No Twitter bearer token configured"}
            headers = {"Authorization": f"Bearer {bearer}", "Content-Type": "application/json"}
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "https://api.twitter.com/2/tweets",
                    json={"text": content},
                    headers=headers
                ) as resp:
                    data = await resp.json()
                    return {"posted": resp.status == 201, "tweet_id": data.get("data", {}).get("id"), "platform": "twitter"}

        if platform == "wordpress":
            wp_url   = integrations.get("wordpress_url")
            wp_user  = integrations.get("wordpress_user")
            wp_pass  = integrations.get("wordpress_app_password")
            if wp_url and wp_user and wp_pass:
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        f"{wp_url}/wp-json/wp/v2/posts",
                        json={"title": content[:60], "content": content, "status": "publish"},
                        auth=aiohttp.BasicAuth(wp_user, wp_pass)
                    ) as resp:
                        data = await resp.json()
                        return {"posted": resp.status == 201, "post_id": data.get("id"), "platform": "wordpress"}

        # Generic webhook fallback
        webhook = integrations.get(f"{platform}_webhook")
        if webhook:
            async with aiohttp.ClientSession() as session:
                async with session.post(webhook, json={"content": content, "platform": platform}) as resp:
                    return {"posted": resp.status < 300, "platform": platform, "type": "webhook"}

        return {"posted": False, "note": f"No integration configured for {platform}"}
