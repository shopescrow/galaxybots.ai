"""
Data tools — read operations scoped to a specific plugged-in business.
All methods receive the adapter config and query the right data source.
"""

import os
import json
import aiohttp
from typing import Optional


class DataTools:
    def __init__(self, adapter: dict):
        self.adapter = adapter
        self.company_id = adapter.get("company_id", "unknown")

    def _db_url(self) -> Optional[str]:
        return self.adapter.get("integrations", {}).get("database_url") or os.getenv("DATABASE_URL")

    def _crm_config(self) -> dict:
        return self.adapter.get("integrations", {}).get("crm", {})

    async def get_company_info(self) -> dict:
        """Return the full business profile and configuration."""
        return {
            "company_id":   self.company_id,
            "name":         self.adapter.get("name"),
            "industry":     self.adapter.get("industry"),
            "description":  self.adapter.get("description"),
            "tone":         self.adapter.get("tone"),
            "sops":         self.adapter.get("sops", []),
            "integrations": list(self.adapter.get("integrations", {}).keys()),
            "bot_permissions": self.adapter.get("bot_permissions", {}),
            "escalation_rules": self.adapter.get("escalation_rules", []),
        }

    async def list_customers(self, filter: Optional[str] = None, limit: int = 20) -> dict:
        """
        List customers. Tries CRM first, falls back to local JSON store.
        Supports filters: 'active', 'overdue', 'new', 'vip'
        """
        crm = self._crm_config()

        # HubSpot integration
        if crm.get("type") == "hubspot" and crm.get("api_key"):
            url = "https://api.hubapi.com/crm/v3/objects/contacts"
            params = {"limit": limit, "hapikey": crm["api_key"]}
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params) as resp:
                    data = await resp.json()
                    return {"customers": data.get("results", []), "source": "hubspot", "count": len(data.get("results", []))}

        # Local JSON store fallback
        store_path = f"data/{self.company_id}/customers.json"
        if os.path.exists(store_path):
            with open(store_path) as f:
                customers = json.load(f)
            if filter:
                customers = [c for c in customers if c.get("status") == filter or c.get("tags", []) and filter in c["tags"]]
            return {"customers": customers[:limit], "source": "local", "count": len(customers)}

        return {"customers": [], "source": "none", "note": "No CRM configured. Add hubspot or database_url to adapter."}

    async def get_customer(self, customer_id: str) -> dict:
        """Get full details for a specific customer."""
        store_path = f"data/{self.company_id}/customers.json"
        if os.path.exists(store_path):
            with open(store_path) as f:
                customers = json.load(f)
            match = next((c for c in customers if str(c.get("id")) == str(customer_id)), None)
            if match:
                return {"customer": match, "found": True}

        return {"found": False, "customer_id": customer_id}

    async def get_open_tasks(self, priority: str = "all", assigned_to: Optional[str] = None) -> dict:
        """Get open tasks from the task store."""
        store_path = f"data/{self.company_id}/tasks.json"
        if not os.path.exists(store_path):
            return {"tasks": [], "note": "No task store found. Create data/{company_id}/tasks.json"}

        with open(store_path) as f:
            tasks = json.load(f)

        open_tasks = [t for t in tasks if t.get("status") not in ("done", "cancelled")]

        if priority != "all":
            open_tasks = [t for t in open_tasks if t.get("priority") == priority]

        if assigned_to:
            open_tasks = [t for t in open_tasks if t.get("assignee") == assigned_to]

        return {"tasks": open_tasks, "count": len(open_tasks), "priority_filter": priority}

    async def get_metrics(self, metric: str, period: str = "this_week") -> dict:
        """
        Get business KPIs. Reads from metrics store or external analytics.
        Add your analytics integration (Stripe, GA4, etc.) here.
        """
        # Check for Stripe revenue data
        stripe_key = self.adapter.get("integrations", {}).get("stripe_secret_key") or os.getenv("STRIPE_SECRET_KEY")
        if metric == "revenue" and stripe_key:
            # Map period to Stripe timestamp
            import time
            period_map = {
                "today": int(time.time()) - 86400,
                "this_week": int(time.time()) - 604800,
                "last_30_days": int(time.time()) - 2592000,
            }
            created_gte = period_map.get(period, period_map["this_week"])

            url = "https://api.stripe.com/v1/charges"
            params = {"limit": 100, "created[gte]": created_gte}
            headers = {"Authorization": f"Bearer {stripe_key}"}
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params, headers=headers) as resp:
                    data = await resp.json()
                    charges = data.get("data", [])
                    total = sum(c["amount"] for c in charges if c["paid"]) / 100
                    return {"metric": "revenue", "value": total, "currency": "usd", "period": period, "source": "stripe"}

        # Local metrics store fallback
        store_path = f"data/{self.company_id}/metrics.json"
        if os.path.exists(store_path):
            with open(store_path) as f:
                metrics = json.load(f)
            return {"metric": metric, "data": metrics.get(metric, {}), "period": period, "source": "local"}

        return {"metric": metric, "value": None, "note": "No metrics source configured", "period": period}

    async def search_records(self, query: str, record_type: str = "all") -> dict:
        """Simple full-text search across local JSON stores."""
        query_lower = query.lower()
        results = []

        types_to_search = ["customers", "tasks", "orders", "leads"] if record_type == "all" else [record_type]

        for rtype in types_to_search:
            path = f"data/{self.company_id}/{rtype}.json"
            if not os.path.exists(path):
                continue
            with open(path) as f:
                records = json.load(f)
            for record in records:
                if query_lower in json.dumps(record).lower():
                    results.append({"type": rtype, **record})

        return {"results": results, "count": len(results), "query": query}
