"""
Universal tools — work for any business, no adapter required.
"""

import os
import asyncio
import aiohttp
import aiofiles
from datetime import datetime
from typing import Optional


class UniversalTools:

    async def web_search(self, query: str, num_results: int = 5) -> dict:
        """
        Search the web. Uses SerpAPI if SERPAPI_KEY is set,
        otherwise returns a stub for development.
        """
        api_key = os.getenv("SERPAPI_KEY")
        if not api_key:
            return {
                "results": [
                    {"title": f"[DEV] Result for: {query}", "url": "https://example.com", "snippet": "Set SERPAPI_KEY to enable real search."}
                ],
                "query": query,
                "note": "No SERPAPI_KEY set — using stub response"
            }

        url = "https://serpapi.com/search"
        params = {"q": query, "num": num_results, "api_key": api_key, "engine": "google"}

        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                data = await resp.json()
                organic = data.get("organic_results", [])
                return {
                    "results": [
                        {"title": r.get("title"), "url": r.get("link"), "snippet": r.get("snippet")}
                        for r in organic[:num_results]
                    ],
                    "query": query
                }

    async def send_email(self, to: str, subject: str, body: str, cc: Optional[str] = None) -> dict:
        """
        Send email via SendGrid if SENDGRID_API_KEY is set,
        otherwise logs to console for development.
        """
        api_key  = os.getenv("SENDGRID_API_KEY")
        from_email = os.getenv("FROM_EMAIL", "bot@galaxybots.ai")

        if not api_key:
            print(f"[DEV EMAIL] To: {to} | Subject: {subject}\n{body}")
            return {"sent": False, "note": "Set SENDGRID_API_KEY to send real emails", "to": to, "subject": subject}

        payload = {
            "personalizations": [{"to": [{"email": to}]}],
            "from": {"email": from_email},
            "subject": subject,
            "content": [{"type": "text/plain", "value": body}]
        }
        if cc:
            payload["personalizations"][0]["cc"] = [{"email": cc}]

        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.post("https://api.sendgrid.com/v3/mail/send", json=payload, headers=headers) as resp:
                return {"sent": resp.status == 202, "status_code": resp.status, "to": to}

    async def http_request(
        self,
        url: str,
        method: str = "GET",
        headers: Optional[dict] = None,
        body: Optional[dict] = None
    ) -> dict:
        """Make an arbitrary HTTP request to any external API."""
        async with aiohttp.ClientSession() as session:
            kwargs = {"headers": headers or {}}
            if body:
                kwargs["json"] = body

            async with session.request(method, url, **kwargs) as resp:
                try:
                    data = await resp.json()
                except Exception:
                    data = await resp.text()

                return {
                    "status_code": resp.status,
                    "data": data,
                    "url": url,
                    "method": method
                }

    async def read_file(self, path: str) -> dict:
        """Read a file from disk."""
        try:
            async with aiofiles.open(path, "r") as f:
                content = await f.read()
            return {"content": content, "path": path, "success": True}
        except FileNotFoundError:
            return {"error": f"File not found: {path}", "success": False}
        except Exception as e:
            return {"error": str(e), "success": False}

    async def write_file(self, path: str, content: str, mode: str = "write") -> dict:
        """Write or append to a file."""
        file_mode = "a" if mode == "append" else "w"
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
            async with aiofiles.open(path, file_mode) as f:
                await f.write(content)
            return {"success": True, "path": path, "mode": mode}
        except Exception as e:
            return {"error": str(e), "success": False}

    async def schedule_task(self, task: str, run_at: str, assignee: Optional[str] = None) -> dict:
        """
        Schedule a task. Writes to a tasks queue file.
        In production, hook this into Celery, APScheduler, or a cron service.
        """
        task_entry = {
            "task": task,
            "run_at": run_at,
            "assignee": assignee or "bot",
            "created_at": datetime.utcnow().isoformat(),
            "status": "scheduled"
        }

        queue_path = "data/task_queue.jsonl"
        os.makedirs("data", exist_ok=True)
        async with aiofiles.open(queue_path, "a") as f:
            await f.write(f"{__import__('json').dumps(task_entry)}\n")

        print(f"[SCHEDULED] {run_at} → {task} (assignee: {assignee or 'bot'})")
        return {"scheduled": True, "task": task, "run_at": run_at}
