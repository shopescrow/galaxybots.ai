# GalaxyBots MCP Server

Autonomous business operator powered by Claude. Plug in any company and let the bots run it.

## Quickstart on Replit

1. **Upload these files** to your Replit project
2. **Set secrets** in Replit's Secrets tab (use `.env.example` as reference):
   - `ANTHROPIC_API_KEY` — required
   - Others optional (add as you connect integrations)
3. **Install dependencies:**
   ```
   pip install -r requirements.txt
   ```
4. **Start the server:**
   ```
   uvicorn server:app --host 0.0.0.0 --port 8000 --reload
   ```
5. Your MCP endpoint is live at:
   ```
   https://your-replit-url.replit.app/sse/{company_id}
   ```

## Plug in a new business

1. Copy `adapters/acme_corp.yaml` → rename to `adapters/your_company.yaml`
2. Fill in the company profile, SOPs, integrations, and permissions
3. Add seed data to `data/your_company/customers.json` (optional)
4. Run the bot:
   ```
   python bot.py your_company "Check open tasks and send morning standup summary"
   ```

## File structure

```
galaxybots/
├── server.py              # FastAPI MCP server — your SSE endpoint
├── bot.py                 # Claude API caller + CLI runner
├── tools/
│   ├── universal.py       # Web search, email, HTTP, files, scheduler
│   ├── data.py            # Read operations (customers, tasks, metrics)
│   └── actions.py         # Write operations (invoices, workflows, notifications)
├── adapters/
│   ├── loader.py          # Reads YAML/JSON configs
│   └── acme_corp.yaml     # Example business config — copy to add new companies
├── data/
│   └── {company_id}/      # Auto-created per business
│       ├── customers.json
│       ├── tasks.json
│       ├── audit_log.jsonl
│       └── decision_log.jsonl
├── requirements.txt
└── .env.example
```

## Adding a new tool

1. Add the async method to `tools/universal.py`, `data.py`, or `actions.py`
2. Register it in `build_tool_registry()` in `server.py`
3. Add its JSON schema to `TOOL_DEFINITIONS` in `server.py`

## Supported integrations (via adapter YAML)

| Integration | Env var / adapter key |
|---|---|
| Email | `SENDGRID_API_KEY` |
| Payments | `STRIPE_SECRET_KEY` |
| CRM | `HUBSPOT_API_KEY` |
| Slack | `SLACK_WEBHOOK_URL` |
| SMS | `TWILIO_*` |
| Web search | `SERPAPI_KEY` |
| Twitter | adapter `twitter_bearer` |
| WordPress | adapter `wordpress_url/user/app_password` |

## Example bot tasks

```bash
python bot.py acme_corp "Generate and send invoices for all active customers"
python bot.py realty_co "Follow up with leads who haven't responded in 3 days"
python bot.py ecommerce "Check today's orders and flag anything needing attention"
python bot.py acme_corp --interactive   # multi-turn session
```
