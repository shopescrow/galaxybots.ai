"""
GalaxyBot runner — sends tasks to Claude with your MCP server attached.

Usage:
    python bot.py acme_corp "Check for overdue invoices and send reminders"
    python bot.py realty_co "Follow up with all leads from this week"
"""

import os
import sys
import json
import asyncio
import aiohttp
from datetime import datetime


ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
MCP_SERVER_URL    = os.getenv("MCP_SERVER_URL", "http://localhost:8000")
MODEL             = "claude-sonnet-4-20250514"


SYSTEM_PROMPT = """You are GalaxyBot, a fully autonomous business operator.

You have been given a set of tools to run the business described in your company context.
Before taking any action:
1. Call get_company_info to understand the business, its SOPs, and your permissions.
2. Follow the SOPs strictly — they define how this business operates.
3. Check bot_permissions before taking write actions. If a permission is false, log the decision with requires_review=true and notify a human instead.
4. Log every significant decision using log_decision, including your reasoning.
5. When uncertain (confidence < 0.7), flag for human review rather than guessing.

You are running fully autonomously. Be thorough, methodical, and professional.
Always confirm what you did at the end with a clear summary."""


async def run_bot(company_id: str, task: str, verbose: bool = True) -> str:
    """
    Run a task autonomously using Claude + your MCP server.
    Returns the final response text.
    """
    if not ANTHROPIC_API_KEY:
        raise ValueError("ANTHROPIC_API_KEY environment variable not set")

    mcp_url = f"{MCP_SERVER_URL}/sse/{company_id}"

    payload = {
        "model":      MODEL,
        "max_tokens": 4096,
        "system":     SYSTEM_PROMPT,
        "messages":   [{"role": "user", "content": task}],
        "mcp_servers": [
            {
                "type": "url",
                "url":  mcp_url,
                "name": f"galaxybots-{company_id}"
            }
        ]
    }

    headers = {
        "x-api-key":         ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type":      "application/json",
        "anthropic-beta":    "mcp-client-2025-04-04"
    }

    if verbose:
        print(f"\n{'='*60}")
        print(f"  GalaxyBot | {company_id} | {datetime.now().strftime('%H:%M:%S')}")
        print(f"  Task: {task}")
        print(f"{'='*60}\n")

    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://api.anthropic.com/v1/messages",
            json=payload,
            headers=headers
        ) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                raise Exception(f"API error {resp.status}: {error_text}")

            data = await resp.json()

    # Extract all text from response
    full_text = "\n".join(
        block["text"]
        for block in data.get("content", [])
        if block.get("type") == "text"
    )

    if verbose:
        print(full_text)
        usage = data.get("usage", {})
        print(f"\n[tokens: {usage.get('input_tokens', 0)} in / {usage.get('output_tokens', 0)} out]")

    return full_text


async def run_conversation(company_id: str, verbose: bool = True):
    """
    Interactive multi-turn bot session.
    Type tasks one at a time; the bot executes each autonomously.
    """
    print(f"\nGalaxyBot interactive mode — company: {company_id}")
    print("Type a task and press Enter. Ctrl+C to exit.\n")

    history = []

    while True:
        try:
            task = input("Task > ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nShutting down.")
            break

        if not task:
            continue

        history.append({"role": "user", "content": task})

        if not ANTHROPIC_API_KEY:
            print("Error: ANTHROPIC_API_KEY not set")
            continue

        payload = {
            "model":      MODEL,
            "max_tokens": 4096,
            "system":     SYSTEM_PROMPT,
            "messages":   history,
            "mcp_servers": [
                {
                    "type": "url",
                    "url":  f"{MCP_SERVER_URL}/sse/{company_id}",
                    "name": f"galaxybots-{company_id}"
                }
            ]
        }

        headers = {
            "x-api-key":         ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type":      "application/json",
            "anthropic-beta":    "mcp-client-2025-04-04"
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.anthropic.com/v1/messages",
                json=payload,
                headers=headers
            ) as resp:
                data = await resp.json()

        reply = "\n".join(
            b["text"] for b in data.get("content", []) if b.get("type") == "text"
        )
        history.append({"role": "assistant", "content": reply})
        print(f"\nBot: {reply}\n")


# ── CLI entry point ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python bot.py <company_id> '<task>'          # run single task")
        print("  python bot.py <company_id> --interactive     # multi-turn session")
        sys.exit(1)

    company = sys.argv[1]

    if len(sys.argv) >= 3 and sys.argv[2] == "--interactive":
        asyncio.run(run_conversation(company))
    elif len(sys.argv) >= 3:
        task = " ".join(sys.argv[2:])
        asyncio.run(run_bot(company, task))
    else:
        # Default demo task
        asyncio.run(run_bot(company, "Check company info, list open tasks, and give me a status summary."))
