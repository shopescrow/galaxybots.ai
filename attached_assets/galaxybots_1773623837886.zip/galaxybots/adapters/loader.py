"""
Adapter loader — reads per-company YAML/JSON config files.
Each file defines everything the bot needs to know to run that business.
"""

import os
import yaml
import json
from typing import Optional


class AdapterLoader:

    ADAPTERS_DIR = "adapters"

    @classmethod
    def load(cls, company_id: str) -> dict:
        """Load adapter config for a company. Tries YAML then JSON."""
        for ext in ("yaml", "yml", "json"):
            path = os.path.join(cls.ADAPTERS_DIR, f"{company_id}.{ext}")
            if os.path.exists(path):
                with open(path) as f:
                    if ext == "json":
                        config = json.load(f)
                    else:
                        config = yaml.safe_load(f)
                config["company_id"] = company_id
                return config

        # Return a minimal default so the server doesn't crash on unknown company
        print(f"[WARN] No adapter found for '{company_id}'. Using defaults.")
        return {
            "company_id":      company_id,
            "name":            company_id,
            "industry":        "unknown",
            "description":     "No adapter configured.",
            "tone":            "professional",
            "sops":            [],
            "integrations":    {},
            "bot_permissions": {},
            "workflows":       {},
            "escalation_rules": []
        }

    @classmethod
    def list_companies(cls) -> list:
        """Return all configured company IDs."""
        if not os.path.exists(cls.ADAPTERS_DIR):
            return []
        companies = []
        for f in os.listdir(cls.ADAPTERS_DIR):
            if f.endswith((".yaml", ".yml", ".json")):
                companies.append(f.rsplit(".", 1)[0])
        return companies
